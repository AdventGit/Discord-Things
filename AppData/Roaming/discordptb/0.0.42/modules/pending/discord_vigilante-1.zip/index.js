module.exports = require('./discord_vigilante.node');
